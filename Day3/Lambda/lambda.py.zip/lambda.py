def lambdaHandler(ebent, context):
    print("Hello from my lambda -nsp")
def lambdaHandler(event, context):
    print("Hello from my lambda -nsp")